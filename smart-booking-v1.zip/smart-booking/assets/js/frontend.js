/**
 * Smart-Booking – Frontend JavaScript (ES6+)
 *
 * Gestiona el flujo completo de reservas:
 *  1. Selección de servicio
 *  2. Inicialización de FullCalendar y carga de slots disponibles
 *  3. Validación del formulario en cliente
 *  4. Envío asíncrono a la REST API con manejo de errores
 *
 * @package Smart_Booking
 */

'use strict';

(function () {

    // ── Estado de la aplicación ─────────────────────────────────────────────
    const state = {
        selectedService:  null,
        selectedDate:     null,
        selectedSlot:     null,
        calendar:         null,
        isSubmitting:     false,
    };

    // ── Elementos del DOM ───────────────────────────────────────────────────
    const el = {
        step1:           () => document.getElementById('sb-step-1'),
        step2:           () => document.getElementById('sb-step-2'),
        step3:           () => document.getElementById('sb-step-3'),
        step4:           () => document.getElementById('sb-step-4'),
        serviceCards:    () => document.querySelectorAll('.sb-service-card'),
        backStep1:       () => document.getElementById('sb-back-step1'),
        backStep2:       () => document.getElementById('sb-back-step2'),
        calendarEl:      () => document.getElementById('sb-calendar'),
        slotsGrid:       () => document.getElementById('sb-slots-grid'),
        slotsLoading:    () => document.getElementById('sb-slots-loading'),
        slotsDateTitle:  () => document.getElementById('sb-slots-date-title'),
        summaryService:  () => document.getElementById('sb-summary-service'),
        summaryDate:     () => document.getElementById('sb-summary-date'),
        summaryTime:     () => document.getElementById('sb-summary-time'),
        fieldService:    () => document.getElementById('sb-field-service'),
        fieldDate:       () => document.getElementById('sb-field-date'),
        fieldStart:      () => document.getElementById('sb-field-start'),
        fieldName:       () => document.getElementById('sb-field-name'),
        fieldPhone:      () => document.getElementById('sb-field-phone'),
        errorName:       () => document.getElementById('sb-error-name'),
        errorPhone:      () => document.getElementById('sb-error-phone'),
        form:            () => document.getElementById('sb-booking-form'),
        submitBtn:       () => document.getElementById('sb-submit-btn'),
        submitText:      () => document.getElementById('sb-submit-text'),
        submitSpinner:   () => document.getElementById('sb-submit-spinner'),
        successDetails:  () => document.getElementById('sb-success-details'),
        newBookingBtn:   () => document.getElementById('sb-new-booking'),
        notification:    () => document.getElementById('sb-notification'),
    };

    // ── Utilidades ──────────────────────────────────────────────────────────

    /**
     * Muestra/oculta un paso del wizard.
     * @param {HTMLElement} show  Elemento a mostrar.
     * @param {HTMLElement} hide  Elemento a ocultar.
     */
    function switchStep(show, hide) {
        if (hide) {
            hide.classList.add('sb-step-hidden');
            hide.classList.remove('sb-step-active');
        }
        if (show) {
            show.classList.remove('sb-step-hidden');
            show.classList.add('sb-step-active');
            show.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }

    /**
     * Muestra una notificación temporal.
     * @param {string} message  Texto del mensaje.
     * @param {'success'|'error'|'warning'} type  Tipo de notificación.
     * @param {number} duration  Duración en ms (por defecto 4000).
     */
    function showNotification(message, type = 'success', duration = 4000) {
        const notif = el.notification();
        notif.textContent = message;
        notif.className = `sb-notification sb-notification-${type}`;
        notif.classList.remove('sb-hidden');

        clearTimeout(notif._timer);
        notif._timer = setTimeout(() => {
            notif.classList.add('sb-hidden');
        }, duration);
    }

    /**
     * Formatea una fecha ISO (YYYY-MM-DD) en formato legible.
     * @param {string} dateStr  Fecha en formato ISO.
     * @returns {string}
     */
    function formatDate(dateStr) {
        const [year, month, day] = dateStr.split('-');
        const months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
                        'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
        return `${parseInt(day)} de ${months[parseInt(month) - 1]} de ${year}`;
    }

    /**
     * Obtiene la etiqueta legible de un servicio.
     * @param {string} serviceKey  Clave del servicio.
     * @returns {string}
     */
    function getServiceLabel(serviceKey) {
        const services = window.sbConfig?.services || window.sbServices || {};
        return services[serviceKey]?.label || serviceKey;
    }

    // ── Paso 1: Selección de servicio ───────────────────────────────────────

    function initServiceSelection() {
        el.serviceCards().forEach(card => {
            card.addEventListener('click', () => {
                // Desmarcar selección anterior
                el.serviceCards().forEach(c => c.classList.remove('sb-selected'));

                // Marcar la nueva selección
                card.classList.add('sb-selected');
                state.selectedService = card.dataset.service;

                // Avanzar al paso 2 con un pequeño delay para la animación
                setTimeout(() => {
                    switchStep(el.step2(), el.step1());
                    initCalendar();
                }, 200);
            });
        });
    }

    // ── Paso 2: Calendario FullCalendar ─────────────────────────────────────

    function initCalendar() {
        // Destruir instancia anterior si existe
        if (state.calendar) {
            state.calendar.destroy();
            state.calendar = null;
        }

        const calendarEl = el.calendarEl();
        if (!calendarEl || typeof FullCalendar === 'undefined') {
            console.error('[Smart-Booking] FullCalendar no está disponible.');
            return;
        }

        const today = new Date().toISOString().split('T')[0];

        state.calendar = new FullCalendar.Calendar(calendarEl, {
            initialView:     'dayGridMonth',
            locale:          'es',
            height:          'auto',
            headerToolbar: {
                left:   'prev,next today',
                center: 'title',
                right:  '',
            },
            validRange: {
                start: today,
                end:   addDays(today, 90),
            },
            // Cargar eventos desde la REST API
            events: {
                url:    `${sbConfig.apiBase}/bookings`,
                method: 'GET',
                extraParams: () => ({}),
                failure: () => {
                    showNotification('No se pudieron cargar los eventos del calendario.', 'warning');
                },
            },
            eventSources: [
                {
                    url:    `${sbConfig.apiBase}/bookings`,
                    method: 'GET',
                    extraParams: () => ({}),
                }
            ],
            // Clic en un día: cargar slots disponibles
            dateClick: (info) => {
                const clickedDate = info.dateStr;
                const todayStr    = new Date().toISOString().split('T')[0];

                if (clickedDate < todayStr) {
                    showNotification('No puedes seleccionar fechas pasadas.', 'warning');
                    return;
                }

                state.selectedDate = clickedDate;
                state.selectedSlot = null;

                // Resaltar día seleccionado
                document.querySelectorAll('.fc-daygrid-day').forEach(d => {
                    d.style.background = '';
                });
                if (info.dayEl) {
                    info.dayEl.style.background = 'rgba(99,102,241,.12)';
                }

                loadSlots(clickedDate);
            },
        });

        state.calendar.render();
    }

    /**
     * Suma días a una fecha ISO.
     * @param {string} dateStr  Fecha base.
     * @param {number} days     Días a sumar.
     * @returns {string}
     */
    function addDays(dateStr, days) {
        const d = new Date(dateStr);
        d.setDate(d.getDate() + days);
        return d.toISOString().split('T')[0];
    }

    // ── Carga de slots disponibles ──────────────────────────────────────────

    async function loadSlots(date) {
        const slotsGrid    = el.slotsGrid();
        const slotsLoading = el.slotsLoading();
        const dateTitle    = el.slotsDateTitle();

        // Actualizar título
        dateTitle.textContent = formatDate(date);

        // Mostrar spinner
        slotsGrid.innerHTML = '';
        slotsLoading.classList.remove('sb-hidden');

        try {
            const url      = `${sbConfig.apiBase}/slots?date=${encodeURIComponent(date)}&service_type=${encodeURIComponent(state.selectedService)}`;
            const response = await fetch(url, {
                headers: {
                    'X-WP-Nonce': sbConfig.nonce,
                    'Accept':     'application/json',
                },
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const data = await response.json();

            slotsLoading.classList.add('sb-hidden');

            if (!data.success || !data.slots?.length) {
                slotsGrid.innerHTML = '<p class="sb-slots-placeholder">No hay horarios disponibles para esta fecha.</p>';
                return;
            }

            renderSlots(data.slots, date);

        } catch (err) {
            console.error('[Smart-Booking] Error cargando slots:', err);
            slotsLoading.classList.add('sb-hidden');
            slotsGrid.innerHTML = '<p class="sb-slots-placeholder" style="color:#ef4444">Error al cargar los horarios. Intenta nuevamente.</p>';
        }
    }

    /**
     * Renderiza los botones de slots en el panel lateral.
     * @param {Array}  slots  Lista de slots con {start, end, available}.
     * @param {string} date   Fecha seleccionada.
     */
    function renderSlots(slots, date) {
        const grid = el.slotsGrid();
        grid.innerHTML = '';

        slots.forEach(slot => {
            const btn = document.createElement('button');
            btn.type      = 'button';
            btn.textContent = `${slot.start} – ${slot.end}`;

            if (slot.available) {
                btn.className = 'sb-slot-btn sb-slot-available';
                btn.addEventListener('click', () => selectSlot(slot, date, btn));
            } else {
                btn.className  = 'sb-slot-btn sb-slot-occupied';
                btn.disabled   = true;
                btn.title      = 'Horario ocupado';
            }

            grid.appendChild(btn);
        });
    }

    /**
     * Selecciona un slot y avanza al paso 3.
     * @param {{start: string, end: string}} slot  Slot seleccionado.
     * @param {string} date  Fecha seleccionada.
     * @param {HTMLElement} btn  Botón clickeado.
     */
    function selectSlot(slot, date, btn) {
        // Desmarcar selección anterior
        document.querySelectorAll('.sb-slot-btn').forEach(b => b.classList.remove('sb-selected'));
        btn.classList.add('sb-selected');

        state.selectedSlot = slot;

        // Actualizar campos ocultos y resumen
        const serviceLabel = getServiceLabel(state.selectedService);

        el.fieldService().value  = state.selectedService;
        el.fieldDate().value     = date;
        el.fieldStart().value    = slot.start;

        el.summaryService().textContent = serviceLabel;
        el.summaryDate().textContent    = formatDate(date);
        el.summaryTime().textContent    = `${slot.start} – ${slot.end}`;

        // Avanzar al paso 3
        setTimeout(() => {
            switchStep(el.step3(), el.step2());
        }, 200);
    }

    // ── Paso 3: Validación y envío del formulario ───────────────────────────

    function initForm() {
        const form = el.form();
        if (!form) return;

        // Validación en tiempo real
        el.fieldName()?.addEventListener('input', () => validateField('name'));
        el.fieldPhone()?.addEventListener('input', () => validateField('phone'));

        form.addEventListener('submit', handleSubmit);
    }

    /**
     * Valida un campo individual y muestra/oculta el mensaje de error.
     * @param {'name'|'phone'} field  Campo a validar.
     * @returns {boolean}
     */
    function validateField(field) {
        if (field === 'name') {
            const val   = el.fieldName().value.trim();
            const error = el.errorName();
            if (!val || val.length < 2) {
                error.textContent = 'El nombre debe tener al menos 2 caracteres.';
                el.fieldName().classList.add('sb-input-error');
                return false;
            }
            if (!/^[\p{L}\s\-\.]+$/u.test(val)) {
                error.textContent = 'Solo se permiten letras, espacios, guiones y puntos.';
                el.fieldName().classList.add('sb-input-error');
                return false;
            }
            error.textContent = '';
            el.fieldName().classList.remove('sb-input-error');
            return true;
        }

        if (field === 'phone') {
            const val   = el.fieldPhone().value.replace(/\D/g, '');
            const error = el.errorPhone();
            if (val.length < 7 || val.length > 15) {
                error.textContent = 'El número debe tener entre 7 y 15 dígitos.';
                el.fieldPhone().classList.add('sb-input-error');
                return false;
            }
            error.textContent = '';
            el.fieldPhone().classList.remove('sb-input-error');
            return true;
        }

        return true;
    }

    /**
     * Maneja el envío del formulario con validación completa y petición a la API.
     * @param {SubmitEvent} e
     */
    async function handleSubmit(e) {
        e.preventDefault();

        if (state.isSubmitting) return;

        // Validar todos los campos
        const nameValid  = validateField('name');
        const phoneValid = validateField('phone');

        if (!nameValid || !phoneValid) {
            showNotification('Por favor corrige los errores antes de continuar.', 'error');
            return;
        }

        // Verificar que los campos ocultos estén completos
        if (!el.fieldService().value || !el.fieldDate().value || !el.fieldStart().value) {
            showNotification('Selección incompleta. Por favor vuelve al paso anterior.', 'error');
            return;
        }

        // Deshabilitar botón y mostrar spinner
        state.isSubmitting = true;
        el.submitBtn().disabled     = true;
        el.submitText().textContent = 'Procesando...';
        el.submitSpinner().classList.remove('sb-hidden');

        const payload = {
            user_name:      el.fieldName().value.trim(),
            service_type:   el.fieldService().value,
            booking_date:   el.fieldDate().value,
            start_time:     el.fieldStart().value,
            whatsapp_phone: el.fieldPhone().value.replace(/\D/g, ''),
        };

        try {
            const response = await fetch(`${sbConfig.apiBase}/bookings`, {
                method:  'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce':   sbConfig.nonce,
                },
                body: JSON.stringify(payload),
            });

            const data = await response.json();

            if (response.ok && data.success) {
                showSuccessScreen(payload, data);
            } else if (response.status === 409) {
                // Conflicto de horario (overbooking detectado en servidor)
                showNotification(
                    data.errors?.[0] || 'El horario ya fue tomado. Por favor elige otro.',
                    'error',
                    6000
                );
                // Recargar slots para mostrar el estado actualizado
                if (state.selectedDate) {
                    switchStep(el.step2(), el.step3());
                    loadSlots(state.selectedDate);
                }
            } else {
                const errorMsg = data.errors?.[0] || 'Error al procesar la reserva.';
                showNotification(errorMsg, 'error', 6000);
            }

        } catch (err) {
            console.error('[Smart-Booking] Error en el envío:', err);
            showNotification('Error de conexión. Verifica tu internet e intenta nuevamente.', 'error');
        } finally {
            state.isSubmitting = false;
            el.submitBtn().disabled     = false;
            el.submitText().textContent = 'Confirmar Reserva';
            el.submitSpinner().classList.add('sb-hidden');
        }
    }

    // ── Paso 4: Pantalla de éxito ───────────────────────────────────────────

    /**
     * Muestra la pantalla de confirmación exitosa.
     * @param {Object} payload  Datos enviados.
     * @param {Object} data     Respuesta de la API.
     */
    function showSuccessScreen(payload, data) {
        const serviceLabel = getServiceLabel(payload.service_type);

        el.successDetails().innerHTML = `
            <p><strong>N° de Reserva:</strong> #${data.booking_id}</p>
            <p><strong>Servicio:</strong> ${serviceLabel}</p>
            <p><strong>Fecha:</strong> ${formatDate(payload.booking_date)}</p>
            <p><strong>Horario:</strong> ${payload.start_time} – ${data.end_time || '—'}</p>
            <p><strong>Nombre:</strong> ${escapeHtml(payload.user_name)}</p>
            <p><strong>WhatsApp:</strong> +${payload.whatsapp_phone}</p>
        `;

        switchStep(el.step4(), el.step3());
    }

    /**
     * Escapa caracteres HTML para prevenir XSS.
     * @param {string} str
     * @returns {string}
     */
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    // ── Navegación entre pasos ──────────────────────────────────────────────

    function initNavigation() {
        // Volver al paso 1
        el.backStep1()?.addEventListener('click', () => {
            switchStep(el.step1(), el.step2());
            state.selectedDate = null;
            state.selectedSlot = null;
        });

        // Volver al paso 2
        el.backStep2()?.addEventListener('click', () => {
            switchStep(el.step2(), el.step3());
        });

        // Nueva reserva (reiniciar todo)
        el.newBookingBtn()?.addEventListener('click', () => {
            resetApp();
        });
    }

    /**
     * Reinicia el estado completo de la aplicación.
     */
    function resetApp() {
        state.selectedService = null;
        state.selectedDate    = null;
        state.selectedSlot    = null;
        state.isSubmitting    = false;

        // Limpiar formulario
        el.form()?.reset();
        el.errorName().textContent  = '';
        el.errorPhone().textContent = '';
        el.fieldName()?.classList.remove('sb-input-error');
        el.fieldPhone()?.classList.remove('sb-input-error');

        // Desmarcar servicios
        el.serviceCards().forEach(c => c.classList.remove('sb-selected'));

        // Volver al paso 1
        [el.step2(), el.step3(), el.step4()].forEach(s => {
            s?.classList.add('sb-step-hidden');
            s?.classList.remove('sb-step-active');
        });
        el.step1()?.classList.remove('sb-step-hidden');
        el.step1()?.classList.add('sb-step-active');

        // Destruir calendario
        if (state.calendar) {
            state.calendar.destroy();
            state.calendar = null;
        }

        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // ── Inicialización ──────────────────────────────────────────────────────

    function init() {
        if (!document.getElementById('sb-app')) return;

        initServiceSelection();
        initNavigation();
        initForm();
    }

    // Esperar a que el DOM esté listo
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
