/**
 * Smart-Booking – Admin JavaScript (ES6+)
 *
 * Inicializa el calendario FullCalendar en el dashboard de administración
 * y gestiona las acciones de actualización de estado vía REST API.
 *
 * @package Smart_Booking
 */

'use strict';

(function () {

    // ── Inicializar calendario del admin ────────────────────────────────────

    function initAdminCalendar() {
        const calendarEl = document.getElementById('sb-admin-calendar');
        if (!calendarEl || typeof FullCalendar === 'undefined') return;

        const calendar = new FullCalendar.Calendar(calendarEl, {
            initialView:  'dayGridMonth',
            locale:       'es',
            height:       'auto',
            headerToolbar: {
                left:   'prev,next today',
                center: 'title',
                right:  'dayGridMonth,timeGridWeek,listWeek',
            },
            buttonText: {
                today:    'Hoy',
                month:    'Mes',
                week:     'Semana',
                list:     'Lista',
            },
            eventSources: [
                {
                    url:    `${sbAdmin.apiBase}/bookings`,
                    method: 'GET',
                    extraParams: () => ({}),
                    failure: () => {
                        console.warn('[Smart-Booking Admin] No se pudieron cargar los eventos.');
                    },
                }
            ],
            // Al hacer clic en un evento, navegar a la fecha en el dashboard
            eventClick: (info) => {
                const date = info.event.startStr.split('T')[0];
                const url  = new URL(window.location.href);
                url.searchParams.set('sb_date', date);
                window.location.href = url.toString();
            },
            // Tooltip al pasar el mouse
            eventMouseEnter: (info) => {
                const props = info.event.extendedProps;
                info.el.title = `${props.service}\n${info.event.title}\nEstado: ${props.status}`;
            },
        });

        calendar.render();
    }

    // ── Confirmación de acciones destructivas ───────────────────────────────

    function initConfirmations() {
        // Los formularios de cancelación ya tienen onsubmit inline,
        // pero agregamos una capa extra de protección aquí.
        document.querySelectorAll('form[data-confirm]').forEach(form => {
            form.addEventListener('submit', (e) => {
                const msg = form.dataset.confirm || '¿Estás seguro?';
                if (!confirm(msg)) {
                    e.preventDefault();
                }
            });
        });
    }

    // ── Resaltar fila al pasar el mouse ─────────────────────────────────────

    function initTableInteractions() {
        const rows = document.querySelectorAll('.sb-booking-row');
        rows.forEach(row => {
            row.addEventListener('mouseenter', () => {
                row.style.outline = '2px solid rgba(99,102,241,.3)';
            });
            row.addEventListener('mouseleave', () => {
                row.style.outline = '';
            });
        });
    }

    // ── Notificaciones auto-dismiss ─────────────────────────────────────────

    function initNotices() {
        const notices = document.querySelectorAll('.notice.is-dismissible');
        notices.forEach(notice => {
            setTimeout(() => {
                notice.style.transition = 'opacity .5s ease';
                notice.style.opacity    = '0';
                setTimeout(() => notice.remove(), 500);
            }, 4000);
        });
    }

    // ── Inicialización ──────────────────────────────────────────────────────

    function init() {
        initAdminCalendar();
        initConfirmations();
        initTableInteractions();
        initNotices();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
