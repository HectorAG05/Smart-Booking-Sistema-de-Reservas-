<?php
/**
 * Modelo – Entidad Booking
 *
 * Encapsula la lógica de negocio del turno: validación de datos,
 * generación de bloques de 30/60 minutos y cálculo de horario de fin.
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SB_Booking {

    // ─── Servicios disponibles y sus duraciones (en minutos) ──────────────────
    public const SERVICES = [
        'consulta_medica'   => [ 'label' => 'Consulta Médica',    'duration' => 30 ],
        'fisioterapia'      => [ 'label' => 'Fisioterapia',        'duration' => 60 ],
        'entrenamiento'     => [ 'label' => 'Entrenamiento',       'duration' => 60 ],
        'nutricion'         => [ 'label' => 'Nutrición',           'duration' => 30 ],
        'yoga'              => [ 'label' => 'Yoga',                'duration' => 60 ],
        'pilates'           => [ 'label' => 'Pilates',             'duration' => 60 ],
        'evaluacion_medica' => [ 'label' => 'Evaluación Médica',   'duration' => 30 ],
        'masajes'           => [ 'label' => 'Masajes Terapéuticos','duration' => 60 ],
    ];

    // ─── Horario de atención ──────────────────────────────────────────────────
    public const OPEN_HOUR  = 8;   // 08:00
    public const CLOSE_HOUR = 20;  // 20:00

    /**
     * Valida los datos de entrada de un turno.
     *
     * @param array $data Datos crudos del formulario.
     * @return array ['valid' => bool, 'errors' => string[]]
     */
    public static function validate( array $data ): array {
        $errors = [];

        // Nombre de usuario
        $name = trim( $data['user_name'] ?? '' );
        if ( empty( $name ) || strlen( $name ) < 2 || strlen( $name ) > 100 ) {
            $errors[] = 'El nombre debe tener entre 2 y 100 caracteres.';
        }
        if ( ! preg_match( '/^[\p{L}\s\-\.]+$/u', $name ) ) {
            $errors[] = 'El nombre solo puede contener letras, espacios, guiones y puntos.';
        }

        // Tipo de servicio
        $service = $data['service_type'] ?? '';
        if ( ! array_key_exists( $service, self::SERVICES ) ) {
            $errors[] = 'El tipo de servicio seleccionado no es válido.';
        }

        // Fecha
        $date = $data['booking_date'] ?? '';
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
            $errors[] = 'El formato de fecha no es válido (YYYY-MM-DD).';
        } else {
            $booking_ts = strtotime( $date );
            $today_ts   = strtotime( current_time( 'Y-m-d' ) );
            if ( $booking_ts < $today_ts ) {
                $errors[] = 'No se pueden crear turnos en fechas pasadas.';
            }
            if ( $booking_ts > strtotime( '+90 days', $today_ts ) ) {
                $errors[] = 'No se pueden crear turnos con más de 90 días de anticipación.';
            }
        }

        // Hora de inicio
        $start = $data['start_time'] ?? '';
        if ( ! preg_match( '/^\d{2}:\d{2}(:\d{2})?$/', $start ) ) {
            $errors[] = 'El formato de hora de inicio no es válido (HH:MM).';
        } else {
            $hour = (int) explode( ':', $start )[0];
            if ( $hour < self::OPEN_HOUR || $hour >= self::CLOSE_HOUR ) {
                $errors[] = sprintf(
                    'El horario de atención es de %02d:00 a %02d:00.',
                    self::OPEN_HOUR,
                    self::CLOSE_HOUR
                );
            }
        }

        // Teléfono WhatsApp
        $phone = preg_replace( '/\D/', '', $data['whatsapp_phone'] ?? '' );
        if ( strlen( $phone ) < 7 || strlen( $phone ) > 15 ) {
            $errors[] = 'El número de WhatsApp debe tener entre 7 y 15 dígitos.';
        }

        return [
            'valid'  => empty( $errors ),
            'errors' => $errors,
        ];
    }

    /**
     * Calcula la hora de fin basándose en el servicio y la hora de inicio.
     *
     * @param string $service_type Clave del servicio.
     * @param string $start_time   Hora de inicio (H:i o H:i:s).
     * @return string Hora de fin en formato H:i:s.
     */
    public static function calculate_end_time( string $service_type, string $start_time ): string {
        $duration = self::SERVICES[ $service_type ]['duration'] ?? 30;
        $ts       = strtotime( $start_time );
        return date( 'H:i:s', $ts + ( $duration * 60 ) );
    }

    /**
     * Genera todos los slots disponibles de un día para un servicio dado,
     * excluyendo los ya ocupados.
     *
     * @param string $date         Fecha en formato Y-m-d.
     * @param string $service_type Clave del servicio.
     * @return array Lista de slots con 'start', 'end' y 'available'.
     */
    public static function generate_slots( string $date, string $service_type ): array {
        $duration = self::SERVICES[ $service_type ]['duration'] ?? 30;
        $occupied = SB_Database::get_occupied_slots( $date, $service_type );

        // Construir lista de rangos ocupados
        $busy = array_map( fn( $row ) => [
            'start' => strtotime( $date . ' ' . $row['start_time'] ),
            'end'   => strtotime( $date . ' ' . $row['end_time'] ),
        ], $occupied );

        $slots      = [];
        $open_ts    = strtotime( $date . ' ' . sprintf( '%02d:00:00', self::OPEN_HOUR ) );
        $close_ts   = strtotime( $date . ' ' . sprintf( '%02d:00:00', self::CLOSE_HOUR ) );
        $step       = $duration * 60;
        $now_ts     = time();

        for ( $ts = $open_ts; $ts + $step <= $close_ts; $ts += $step ) {
            $slot_end  = $ts + $step;
            $available = true;

            // Verificar colisión con turnos existentes
            foreach ( $busy as $b ) {
                if ( $ts < $b['end'] && $slot_end > $b['start'] ) {
                    $available = false;
                    break;
                }
            }

            // Bloquear slots en el pasado
            if ( $ts < $now_ts ) {
                $available = false;
            }

            $slots[] = [
                'start'     => date( 'H:i', $ts ),
                'end'       => date( 'H:i', $slot_end ),
                'available' => $available,
            ];
        }

        return $slots;
    }

    /**
     * Formatea los eventos de la BD para FullCalendar.
     *
     * @param array $rows Filas de la base de datos.
     * @return array Eventos en formato FullCalendar.
     */
    public static function format_for_calendar( array $rows ): array {
        return array_map( function ( $row ) {
            $color = match ( $row['status'] ) {
                'confirmado' => '#10b981',
                'cancelado'  => '#ef4444',
                default      => '#f59e0b',
            };

            $service_label = self::SERVICES[ $row['service_type'] ]['label'] ?? $row['service_type'];

            return [
                'id'    => (int) $row['id'],
                'title' => sprintf( '%s – %s', $service_label, $row['user_name'] ),
                'start' => $row['booking_date'] . 'T' . $row['start_time'],
                'end'   => $row['booking_date'] . 'T' . $row['end_time'],
                'color' => $color,
                'extendedProps' => [
                    'status'  => $row['status'],
                    'service' => $service_label,
                    'user'    => $row['user_name'],
                ],
            ];
        }, $rows );
    }
}
