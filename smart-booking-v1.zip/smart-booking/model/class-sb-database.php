<?php
/**
 * Modelo – Capa de Base de Datos
 *
 * Gestiona la creación de la tabla wp_booking_system y expone métodos
 * de acceso a datos (CRUD) con consultas preparadas para prevenir inyección SQL.
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SB_Database {

    /** Nombre completo de la tabla (con prefijo de WordPress). */
    public static function table_name(): string {
        global $wpdb;
        return $wpdb->prefix . 'booking_system';
    }

    /**
     * Crea la tabla wp_booking_system al activar el plugin.
     * Utiliza dbDelta() para compatibilidad con actualizaciones futuras.
     */
    public static function create_table(): void {
        global $wpdb;

        $table      = self::table_name();
        $charset    = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id              BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_name       VARCHAR(100)        NOT NULL,
            service_type    VARCHAR(100)        NOT NULL,
            booking_date    DATE                NOT NULL,
            start_time      TIME                NOT NULL,
            end_time        TIME                NOT NULL,
            status          ENUM('pendiente','confirmado','cancelado') NOT NULL DEFAULT 'pendiente',
            whatsapp_phone  VARCHAR(20)         NOT NULL,
            created_at      DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_date_time (booking_date, start_time, end_time),
            KEY idx_status    (status)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Elimina la tabla al desactivar el plugin (solo en entornos de desarrollo).
     * En producción se recomienda comentar esta línea.
     */
    public static function maybe_drop_table(): void {
        // Descomenta la siguiente línea SOLO en desarrollo:
        // global $wpdb; $wpdb->query( 'DROP TABLE IF EXISTS ' . self::table_name() );
    }

    // ─── Consultas de disponibilidad ──────────────────────────────────────────

    /**
     * Verifica si existe colisión de horario para una fecha y servicio dados.
     *
     * La lógica de solapamiento cubre todos los casos posibles:
     *   - El nuevo turno empieza dentro de uno existente.
     *   - El nuevo turno termina dentro de uno existente.
     *   - El nuevo turno envuelve completamente a uno existente.
     *
     * @param string $date         Fecha en formato Y-m-d.
     * @param string $start_time   Hora de inicio en formato H:i:s.
     * @param string $end_time     Hora de fin en formato H:i:s.
     * @param string $service_type Tipo de servicio.
     * @param int    $exclude_id   ID a excluir (útil para edición).
     * @return bool TRUE si hay colisión.
     */
    public static function has_overlap(
        string $date,
        string $start_time,
        string $end_time,
        string $service_type,
        int    $exclude_id = 0
    ): bool {
        global $wpdb;

        $table = self::table_name();

        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table}
                 WHERE booking_date  = %s
                   AND service_type  = %s
                   AND status       != 'cancelado'
                   AND id           != %d
                   AND start_time    < %s
                   AND end_time      > %s",
                $date,
                $service_type,
                $exclude_id,
                $end_time,
                $start_time
            )
        );

        return (int) $count > 0;
    }

    /**
     * Inserta un nuevo turno en la base de datos.
     *
     * @param array $data Datos del turno.
     * @return int|false ID insertado o FALSE en caso de error.
     */
    public static function insert_booking( array $data ): int|false {
        global $wpdb;

        $result = $wpdb->insert(
            self::table_name(),
            [
                'user_name'      => sanitize_text_field( $data['user_name'] ),
                'service_type'   => sanitize_text_field( $data['service_type'] ),
                'booking_date'   => sanitize_text_field( $data['booking_date'] ),
                'start_time'     => sanitize_text_field( $data['start_time'] ),
                'end_time'       => sanitize_text_field( $data['end_time'] ),
                'status'         => 'pendiente',
                'whatsapp_phone' => sanitize_text_field( $data['whatsapp_phone'] ),
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );

        return $result ? (int) $wpdb->insert_id : false;
    }

    /**
     * Actualiza el estado de un turno.
     *
     * @param int    $id     ID del turno.
     * @param string $status Nuevo estado.
     * @return bool
     */
    public static function update_status( int $id, string $status ): bool {
        global $wpdb;

        $allowed = [ 'pendiente', 'confirmado', 'cancelado' ];
        if ( ! in_array( $status, $allowed, true ) ) {
            return false;
        }

        return (bool) $wpdb->update(
            self::table_name(),
            [ 'status' => $status ],
            [ 'id'     => $id ],
            [ '%s' ],
            [ '%d' ]
        );
    }

    /**
     * Obtiene todos los turnos de una fecha específica.
     *
     * @param string $date Fecha en formato Y-m-d. Si está vacía usa la fecha actual.
     * @return array
     */
    public static function get_bookings_by_date( string $date = '' ): array {
        global $wpdb;

        if ( empty( $date ) ) {
            $date = current_time( 'Y-m-d' );
        }

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM " . self::table_name() . "
                 WHERE booking_date = %s
                 ORDER BY start_time ASC",
                $date
            ),
            ARRAY_A
        );
    }

    /**
     * Obtiene los slots ocupados de una fecha y servicio para el calendario.
     *
     * @param string $date         Fecha en formato Y-m-d.
     * @param string $service_type Tipo de servicio.
     * @return array
     */
    public static function get_occupied_slots( string $date, string $service_type ): array {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, start_time, end_time, status FROM " . self::table_name() . "
                 WHERE booking_date = %s
                   AND service_type = %s
                   AND status      != 'cancelado'
                 ORDER BY start_time ASC",
                $date,
                $service_type
            ),
            ARRAY_A
        );
    }

    /**
     * Obtiene un turno por su ID.
     *
     * @param int $id ID del turno.
     * @return array|null
     */
    public static function get_booking_by_id( int $id ): ?array {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::table_name() . " WHERE id = %d",
                $id
            ),
            ARRAY_A
        );

        return $row ?: null;
    }

    /**
     * Obtiene todos los turnos para el calendario (formato FullCalendar).
     *
     * @param string $start Fecha de inicio del rango (Y-m-d).
     * @param string $end   Fecha de fin del rango (Y-m-d).
     * @return array
     */
    public static function get_events_for_calendar( string $start, string $end ): array {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, user_name, service_type, booking_date, start_time, end_time, status
                 FROM " . self::table_name() . "
                 WHERE booking_date BETWEEN %s AND %s
                 ORDER BY booking_date ASC, start_time ASC",
                $start,
                $end
            ),
            ARRAY_A
        );
    }
}
