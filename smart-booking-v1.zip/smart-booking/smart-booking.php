<?php
/**
 * Plugin Name:  Smart-Booking
 * Plugin URI:   https://github.com/hector/smart-booking
 * Description:  Sistema de reservas en tiempo real para servicios profesionales (Clínicas/Gimnasios). Elimina el overbooking mediante validación de servidor y envía confirmaciones vía WhatsApp.
 * Version:      1.0.0
 * Author:       Hector George
 * Author URI:   https://hectorgeorge.dev
 * Text Domain:  smart-booking
 * Domain Path:  /languages
 * Requires PHP: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Bloquear acceso directo al archivo.
}

// ─── Constantes globales del plugin ───────────────────────────────────────────
define( 'SB_VERSION',    '1.0.0' );
define( 'SB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ─── Carga de capas MVC ───────────────────────────────────────────────────────
require_once SB_PLUGIN_DIR . 'model/class-sb-database.php';
require_once SB_PLUGIN_DIR . 'model/class-sb-booking.php';
require_once SB_PLUGIN_DIR . 'controller/class-sb-whatsapp.php';
require_once SB_PLUGIN_DIR . 'controller/class-sb-rest-controller.php';
require_once SB_PLUGIN_DIR . 'controller/class-sb-admin-controller.php';
require_once SB_PLUGIN_DIR . 'view/class-sb-shortcode.php';

// ─── Hooks de activación / desactivación ──────────────────────────────────────
register_activation_hook( __FILE__, array( 'SB_Database', 'create_table' ) );
register_deactivation_hook( __FILE__, array( 'SB_Database', 'maybe_drop_table' ) );

// ─── Inicialización ───────────────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {
    SB_Rest_Controller::register();
    SB_Admin_Controller::register();
    SB_Shortcode::register();
} );
