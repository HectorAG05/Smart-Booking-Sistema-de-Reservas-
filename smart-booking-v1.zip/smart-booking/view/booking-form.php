<?php
/**
 * Vista – Formulario de Reservas (Frontend)
 *
 * Plantilla HTML del sistema de reservas. Incluye:
 *  - Selector de servicio y fecha
 *  - Calendario FullCalendar con eventos en tiempo real
 *  - Panel de slots disponibles/ocupados
 *  - Formulario de confirmación
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Devuelve un emoji representativo para cada tipo de servicio.
 *
 * @param string $key Clave del servicio.
 * @return string Emoji.
 */
function sb_get_service_icon( string $key ): string {
    $icons = [
        'consulta_medica'   => '🩺',
        'fisioterapia'      => '🦴',
        'entrenamiento'     => '🏋️',
        'nutricion'         => '🥗',
        'yoga'              => '🧘',
        'pilates'           => '🤸',
        'evaluacion_medica' => '📋',
        'masajes'           => '💆',
    ];
    return $icons[ $key ] ?? '📅';
}
?>

<div id="sb-app" class="sb-container">

    <!-- ── Encabezado ─────────────────────────────────────────────────────── -->
    <div class="sb-header">
        <div class="sb-header-icon">📅</div>
        <div>
            <h2 class="sb-title">Sistema de Reservas</h2>
            <p class="sb-subtitle">Reserva tu turno de forma rápida y segura</p>
        </div>
    </div>

    <!-- ── Paso 1: Selección de servicio ──────────────────────────────────── -->
    <div id="sb-step-1" class="sb-step sb-step-active">
        <div class="sb-step-header">
            <span class="sb-step-number">1</span>
            <h3 class="sb-step-title">Selecciona el Servicio</h3>
        </div>

        <div id="sb-services-grid" class="sb-services-grid">
            <?php foreach ( SB_Booking::SERVICES as $key => $service ) : ?>
            <button
                class="sb-service-card"
                data-service="<?php echo esc_attr( $key ); ?>"
                data-duration="<?php echo esc_attr( $service['duration'] ); ?>"
                type="button"
            >
                <span class="sb-service-icon"><?php echo sb_get_service_icon( $key ); ?></span>
                <span class="sb-service-name"><?php echo esc_html( $service['label'] ); ?></span>
                <span class="sb-service-duration"><?php echo esc_html( $service['duration'] ); ?> min</span>
            </button>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ── Paso 2: Calendario y slots ────────────────────────────────────── -->
    <div id="sb-step-2" class="sb-step sb-step-hidden">
        <div class="sb-step-header">
            <span class="sb-step-number">2</span>
            <h3 class="sb-step-title">Elige Fecha y Horario</h3>
            <button id="sb-back-step1" class="sb-back-btn" type="button">← Volver</button>
        </div>

        <div class="sb-calendar-layout">

            <!-- Calendario FullCalendar -->
            <div class="sb-calendar-wrapper">
                <div id="sb-calendar"></div>
            </div>

            <!-- Panel de slots -->
            <div class="sb-slots-panel">
                <div class="sb-slots-header">
                    <h4 id="sb-slots-date-title">Selecciona una fecha</h4>
                    <div class="sb-legend">
                        <span class="sb-legend-item sb-legend-available">Disponible</span>
                        <span class="sb-legend-item sb-legend-occupied">Ocupado</span>
                    </div>
                </div>

                <div id="sb-slots-loading" class="sb-loading sb-hidden">
                    <div class="sb-spinner"></div>
                    <span>Cargando horarios...</span>
                </div>

                <div id="sb-slots-grid" class="sb-slots-grid">
                    <p class="sb-slots-placeholder">Selecciona una fecha en el calendario para ver los horarios disponibles.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ── Paso 3: Datos del usuario ─────────────────────────────────────── -->
    <div id="sb-step-3" class="sb-step sb-step-hidden">
        <div class="sb-step-header">
            <span class="sb-step-number">3</span>
            <h3 class="sb-step-title">Completa tus Datos</h3>
            <button id="sb-back-step2" class="sb-back-btn" type="button">← Volver</button>
        </div>

        <!-- Resumen de la selección -->
        <div id="sb-booking-summary" class="sb-summary">
            <div class="sb-summary-item">
                <span class="sb-summary-label">Servicio:</span>
                <span id="sb-summary-service" class="sb-summary-value">—</span>
            </div>
            <div class="sb-summary-item">
                <span class="sb-summary-label">Fecha:</span>
                <span id="sb-summary-date" class="sb-summary-value">—</span>
            </div>
            <div class="sb-summary-item">
                <span class="sb-summary-label">Horario:</span>
                <span id="sb-summary-time" class="sb-summary-value">—</span>
            </div>
        </div>

        <!-- Formulario de datos personales -->
        <form id="sb-booking-form" novalidate>
            <input type="hidden" id="sb-field-service"  name="service_type"  value="">
            <input type="hidden" id="sb-field-date"     name="booking_date"  value="">
            <input type="hidden" id="sb-field-start"    name="start_time"    value="">

            <div class="sb-form-group">
                <label for="sb-field-name" class="sb-label">
                    Nombre completo <span class="sb-required">*</span>
                </label>
                <input
                    type="text"
                    id="sb-field-name"
                    name="user_name"
                    class="sb-input"
                    placeholder="Ej: María García"
                    maxlength="100"
                    required
                    autocomplete="name"
                >
                <span class="sb-field-error" id="sb-error-name"></span>
            </div>

            <div class="sb-form-group">
                <label for="sb-field-phone" class="sb-label">
                    WhatsApp (con código de país) <span class="sb-required">*</span>
                </label>
                <div class="sb-phone-wrapper">
                    <span class="sb-phone-prefix">+</span>
                    <input
                        type="tel"
                        id="sb-field-phone"
                        name="whatsapp_phone"
                        class="sb-input sb-input-phone"
                        placeholder="5491112345678"
                        maxlength="15"
                        required
                        autocomplete="tel"
                    >
                </div>
                <span class="sb-field-hint">Incluye el código de país sin el signo +. Ej: 5491112345678</span>
                <span class="sb-field-error" id="sb-error-phone"></span>
            </div>

            <!-- Botón de envío -->
            <button type="submit" id="sb-submit-btn" class="sb-submit-btn">
                <span id="sb-submit-text">Confirmar Reserva</span>
                <span id="sb-submit-spinner" class="sb-spinner sb-hidden"></span>
            </button>
        </form>
    </div>

    <!-- ── Paso 4: Confirmación ───────────────────────────────────────────── -->
    <div id="sb-step-4" class="sb-step sb-step-hidden">
        <div class="sb-success-container">
            <div class="sb-success-icon">✅</div>
            <h3 class="sb-success-title">¡Turno Reservado!</h3>
            <p class="sb-success-message">Tu reserva fue registrada exitosamente. Recibirás una confirmación por WhatsApp en breve.</p>
            <div id="sb-success-details" class="sb-success-details"></div>
            <button id="sb-new-booking" class="sb-new-booking-btn" type="button">
                Hacer otra reserva
            </button>
        </div>
    </div>

    <!-- ── Notificaciones globales ────────────────────────────────────────── -->
    <div id="sb-notification" class="sb-notification sb-hidden" role="alert" aria-live="polite"></div>

</div><!-- /#sb-app -->
