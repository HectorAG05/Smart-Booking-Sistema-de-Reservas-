<?php
/**
 * Vista – Configuración del Plugin
 *
 * Formulario para configurar las credenciales de WhatsApp y datos del negocio.
 *
 * Variables disponibles:
 *   $whatsapp_token   string  Token de la API de WhatsApp
 *   $whatsapp_number  string  Número de WhatsApp del negocio
 *   $business_name    string  Nombre del negocio
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap sb-admin-wrap">

    <div class="sb-admin-header">
        <div class="sb-admin-header-left">
            <h1 class="sb-admin-title">⚙️ Configuración de Smart Booking</h1>
            <p class="sb-admin-subtitle">Configura las integraciones y parámetros del sistema</p>
        </div>
        <div class="sb-admin-header-right">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=smart-booking' ) ); ?>" class="button button-secondary">
                ← Volver al Dashboard
            </a>
        </div>
    </div>

    <div class="sb-admin-card">
        <form method="POST" action="">
            <?php wp_nonce_field( 'sb_settings_nonce' ); ?>
            <input type="hidden" name="sb_save_settings" value="1">

            <!-- ── Datos del Negocio ──────────────────────────────────────── -->
            <div class="sb-settings-section">
                <h2 class="sb-settings-section-title">🏢 Datos del Negocio</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="sb_business_name">Nombre del Negocio</label>
                        </th>
                        <td>
                            <input
                                type="text"
                                id="sb_business_name"
                                name="sb_business_name"
                                value="<?php echo esc_attr( $business_name ); ?>"
                                class="regular-text"
                                placeholder="Ej: Clínica San Martín"
                            >
                            <p class="description">Se usará en los mensajes de confirmación de WhatsApp.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- ── Integración WhatsApp ───────────────────────────────────── -->
            <div class="sb-settings-section">
                <h2 class="sb-settings-section-title">📱 Integración WhatsApp Business API</h2>
                <div class="notice notice-info inline">
                    <p>
                        Para usar la API oficial de WhatsApp Business, necesitas una cuenta en
                        <a href="https://developers.facebook.com/docs/whatsapp" target="_blank" rel="noopener">Meta for Developers</a>.
                        También puedes usar el método de <strong>URL masking</strong> (wa.me) que no requiere token.
                    </p>
                </div>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="sb_whatsapp_token">Token de Acceso (API)</label>
                        </th>
                        <td>
                            <input
                                type="password"
                                id="sb_whatsapp_token"
                                name="sb_whatsapp_token"
                                value="<?php echo esc_attr( $whatsapp_token ); ?>"
                                class="regular-text"
                                placeholder="EAAxxxxxxxx..."
                                autocomplete="new-password"
                            >
                            <p class="description">
                                Token de acceso permanente de la API de WhatsApp Business.
                                Déjalo vacío para usar el método de URL masking (wa.me).
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="sb_whatsapp_number">Número de WhatsApp del Negocio</label>
                        </th>
                        <td>
                            <input
                                type="text"
                                id="sb_whatsapp_number"
                                name="sb_whatsapp_number"
                                value="<?php echo esc_attr( $whatsapp_number ); ?>"
                                class="regular-text"
                                placeholder="5491112345678"
                            >
                            <p class="description">
                                Número con código de país, sin el signo +.
                                Se usará para los mensajes de confirmación.
                            </p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- ── Shortcode ──────────────────────────────────────────────── -->
            <div class="sb-settings-section">
                <h2 class="sb-settings-section-title">🔧 Uso del Shortcode</h2>
                <div class="sb-shortcode-box">
                    <p>Inserta el siguiente shortcode en cualquier página o entrada de WordPress para mostrar el formulario de reservas:</p>
                    <code class="sb-shortcode-code">[smart_booking]</code>
                    <button
                        type="button"
                        class="button button-secondary"
                        onclick="navigator.clipboard.writeText('[smart_booking]').then(() => alert('Copiado al portapapeles'));"
                    >
                        📋 Copiar
                    </button>
                </div>
            </div>

            <!-- ── Tabla de la BD ─────────────────────────────────────────── -->
            <div class="sb-settings-section">
                <h2 class="sb-settings-section-title">🗄️ Información de la Base de Datos</h2>
                <table class="form-table">
                    <tr>
                        <th>Tabla</th>
                        <td><code><?php echo esc_html( SB_Database::table_name() ); ?></code></td>
                    </tr>
                    <tr>
                        <th>Versión del Plugin</th>
                        <td><code><?php echo esc_html( SB_VERSION ); ?></code></td>
                    </tr>
                    <tr>
                        <th>REST API Base</th>
                        <td><code><?php echo esc_html( rest_url( 'smart-booking/v1' ) ); ?></code></td>
                    </tr>
                </table>
            </div>

            <?php submit_button( 'Guardar Configuración', 'primary', 'sb_save_settings' ); ?>
        </form>
    </div>
</div>
