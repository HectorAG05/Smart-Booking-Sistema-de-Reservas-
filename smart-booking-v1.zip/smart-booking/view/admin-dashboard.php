<?php
/**
 * Vista – Dashboard Administrativo
 *
 * Renderiza la tabla de "Turnos del Día" con estadísticas, filtros por fecha
 * y acciones de cambio de estado (confirmar/cancelar).
 *
 * Variables disponibles (inyectadas desde SB_Admin_Controller::render_dashboard):
 *   $filter_date  string  Fecha filtrada (Y-m-d)
 *   $bookings     array   Turnos del día
 *   $stats        array   Estadísticas del día
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Mensaje de éxito/error tras acción
$msg = $_GET['sb_msg'] ?? '';
?>

<div class="wrap sb-admin-wrap">

    <!-- ── Encabezado ─────────────────────────────────────────────────────── -->
    <div class="sb-admin-header">
        <div class="sb-admin-header-left">
            <h1 class="sb-admin-title">
                📅 Smart Booking
                <span class="sb-admin-version">v<?php echo esc_html( SB_VERSION ); ?></span>
            </h1>
            <p class="sb-admin-subtitle">Panel de Gestión de Turnos</p>
        </div>
        <div class="sb-admin-header-right">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=smart-booking-settings' ) ); ?>" class="button button-secondary">
                ⚙️ Configuración
            </a>
        </div>
    </div>

    <!-- ── Notificaciones ─────────────────────────────────────────────────── -->
    <?php if ( 'updated' === $msg ) : ?>
    <div class="notice notice-success is-dismissible">
        <p>✅ Estado del turno actualizado correctamente.</p>
    </div>
    <?php elseif ( 'error' === $msg ) : ?>
    <div class="notice notice-error is-dismissible">
        <p>❌ Ocurrió un error al actualizar el turno. Intenta nuevamente.</p>
    </div>
    <?php endif; ?>

    <!-- ── Tarjetas de estadísticas ───────────────────────────────────────── -->
    <div class="sb-stats-grid">
        <div class="sb-stat-card sb-stat-total">
            <div class="sb-stat-icon">📊</div>
            <div class="sb-stat-content">
                <span class="sb-stat-number"><?php echo esc_html( $stats['total'] ); ?></span>
                <span class="sb-stat-label">Total del Día</span>
            </div>
        </div>
        <div class="sb-stat-card sb-stat-confirmed">
            <div class="sb-stat-icon">✅</div>
            <div class="sb-stat-content">
                <span class="sb-stat-number"><?php echo esc_html( $stats['confirmado'] ); ?></span>
                <span class="sb-stat-label">Confirmados</span>
            </div>
        </div>
        <div class="sb-stat-card sb-stat-pending">
            <div class="sb-stat-icon">⏳</div>
            <div class="sb-stat-content">
                <span class="sb-stat-number"><?php echo esc_html( $stats['pendiente'] ); ?></span>
                <span class="sb-stat-label">Pendientes</span>
            </div>
        </div>
        <div class="sb-stat-card sb-stat-cancelled">
            <div class="sb-stat-icon">❌</div>
            <div class="sb-stat-content">
                <span class="sb-stat-number"><?php echo esc_html( $stats['cancelado'] ); ?></span>
                <span class="sb-stat-label">Cancelados</span>
            </div>
        </div>
    </div>

    <!-- ── Filtro de fecha + Calendario FullCalendar ──────────────────────── -->
    <div class="sb-admin-card">
        <div class="sb-admin-card-header">
            <h2 class="sb-admin-card-title">📆 Turnos del Día</h2>
            <div class="sb-date-filter">
                <form method="GET" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="sb-filter-form">
                    <input type="hidden" name="page" value="smart-booking">
                    <label for="sb_date_filter" class="sb-filter-label">Filtrar por fecha:</label>
                    <input
                        type="date"
                        id="sb_date_filter"
                        name="sb_date"
                        value="<?php echo esc_attr( $filter_date ); ?>"
                        class="sb-date-input"
                        onchange="this.form.submit()"
                    >
                    <button type="submit" class="button button-primary">Filtrar</button>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=smart-booking' ) ); ?>" class="button button-secondary">Hoy</a>
                </form>
            </div>
        </div>

        <!-- Fecha mostrada -->
        <div class="sb-date-display">
            <strong>Mostrando turnos del:</strong>
            <?php
            $display_date = date_create( $filter_date );
            $days_es = ['domingo','lunes','martes','miércoles','jueves','viernes','sábado'];
            $months_es = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
            if ( $display_date ) {
                $dow   = (int) $display_date->format('w');
                $day   = (int) $display_date->format('j');
                $month = (int) $display_date->format('n') - 1;
                $year  = $display_date->format('Y');
                echo esc_html( ucfirst( $days_es[$dow] ) . ', ' . $day . ' de ' . $months_es[$month] . ' de ' . $year );
            }
            ?>
            <?php if ( $filter_date === current_time( 'Y-m-d' ) ) : ?>
            <span class="sb-today-badge">Hoy</span>
            <?php endif; ?>
        </div>

        <!-- ── Tabla de turnos ─────────────────────────────────────────────── -->
        <?php if ( empty( $bookings ) ) : ?>
        <div class="sb-empty-state">
            <div class="sb-empty-icon">📭</div>
            <p class="sb-empty-title">No hay turnos para esta fecha</p>
            <p class="sb-empty-subtitle">Los turnos reservados aparecerán aquí.</p>
        </div>
        <?php else : ?>
        <div class="sb-table-wrapper">
            <table class="wp-list-table widefat fixed striped sb-bookings-table">
                <thead>
                    <tr>
                        <th scope="col" class="column-id">#ID</th>
                        <th scope="col" class="column-time">Horario</th>
                        <th scope="col" class="column-service">Servicio</th>
                        <th scope="col" class="column-client">Cliente</th>
                        <th scope="col" class="column-phone">WhatsApp</th>
                        <th scope="col" class="column-status">Estado</th>
                        <th scope="col" class="column-actions">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $bookings as $booking ) :
                        $service_label = SB_Booking::SERVICES[ $booking['service_type'] ]['label'] ?? $booking['service_type'];
                        $status_class  = match( $booking['status'] ) {
                            'confirmado' => 'sb-badge-success',
                            'cancelado'  => 'sb-badge-danger',
                            default      => 'sb-badge-warning',
                        };
                        $status_icon = match( $booking['status'] ) {
                            'confirmado' => '✅',
                            'cancelado'  => '❌',
                            default      => '⏳',
                        };
                    ?>
                    <tr class="sb-booking-row sb-status-<?php echo esc_attr( $booking['status'] ); ?>">
                        <td class="column-id">
                            <strong>#<?php echo esc_html( $booking['id'] ); ?></strong>
                        </td>
                        <td class="column-time">
                            <span class="sb-time-badge">
                                <?php echo esc_html( substr( $booking['start_time'], 0, 5 ) ); ?>
                                <span class="sb-time-sep">→</span>
                                <?php echo esc_html( substr( $booking['end_time'], 0, 5 ) ); ?>
                            </span>
                        </td>
                        <td class="column-service">
                            <?php echo esc_html( $service_label ); ?>
                            <br>
                            <small class="sb-duration-label">
                                <?php echo esc_html( SB_Booking::SERVICES[ $booking['service_type'] ]['duration'] ?? '—' ); ?> min
                            </small>
                        </td>
                        <td class="column-client">
                            <strong><?php echo esc_html( $booking['user_name'] ); ?></strong>
                        </td>
                        <td class="column-phone">
                            <a
                                href="https://wa.me/<?php echo esc_attr( $booking['whatsapp_phone'] ); ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="sb-whatsapp-link"
                                title="Abrir chat en WhatsApp"
                            >
                                📱 +<?php echo esc_html( $booking['whatsapp_phone'] ); ?>
                            </a>
                        </td>
                        <td class="column-status">
                            <span class="sb-badge <?php echo esc_attr( $status_class ); ?>">
                                <?php echo $status_icon; ?> <?php echo esc_html( ucfirst( $booking['status'] ) ); ?>
                            </span>
                        </td>
                        <td class="column-actions">
                            <?php if ( 'pendiente' === $booking['status'] ) : ?>
                            <form method="POST" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
                                <?php wp_nonce_field( 'sb_status_update' ); ?>
                                <input type="hidden" name="action"      value="sb_update_status">
                                <input type="hidden" name="booking_id"  value="<?php echo esc_attr( $booking['id'] ); ?>">
                                <input type="hidden" name="new_status"  value="confirmado">
                                <input type="hidden" name="filter_date" value="<?php echo esc_attr( $filter_date ); ?>">
                                <button type="submit" class="button button-primary sb-action-btn">
                                    ✅ Confirmar
                                </button>
                            </form>
                            <?php endif; ?>

                            <?php if ( 'cancelado' !== $booking['status'] ) : ?>
                            <form method="POST" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"
                                  onsubmit="return confirm('¿Estás seguro de cancelar este turno?')">
                                <?php wp_nonce_field( 'sb_status_update' ); ?>
                                <input type="hidden" name="action"      value="sb_update_status">
                                <input type="hidden" name="booking_id"  value="<?php echo esc_attr( $booking['id'] ); ?>">
                                <input type="hidden" name="new_status"  value="cancelado">
                                <input type="hidden" name="filter_date" value="<?php echo esc_attr( $filter_date ); ?>">
                                <button type="submit" class="button button-secondary sb-action-btn sb-cancel-btn">
                                    ❌ Cancelar
                                </button>
                            </form>
                            <?php endif; ?>

                            <?php if ( 'cancelado' === $booking['status'] ) : ?>
                            <form method="POST" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
                                <?php wp_nonce_field( 'sb_status_update' ); ?>
                                <input type="hidden" name="action"      value="sb_update_status">
                                <input type="hidden" name="booking_id"  value="<?php echo esc_attr( $booking['id'] ); ?>">
                                <input type="hidden" name="new_status"  value="pendiente">
                                <input type="hidden" name="filter_date" value="<?php echo esc_attr( $filter_date ); ?>">
                                <button type="submit" class="button sb-action-btn">
                                    🔄 Reactivar
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="7" class="sb-table-footer">
                            Total de turnos: <strong><?php echo esc_html( $stats['total'] ); ?></strong>
                            &nbsp;|&nbsp;
                            Confirmados: <strong style="color:#10b981"><?php echo esc_html( $stats['confirmado'] ); ?></strong>
                            &nbsp;|&nbsp;
                            Pendientes: <strong style="color:#f59e0b"><?php echo esc_html( $stats['pendiente'] ); ?></strong>
                            &nbsp;|&nbsp;
                            Cancelados: <strong style="color:#ef4444"><?php echo esc_html( $stats['cancelado'] ); ?></strong>
                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <!-- ── Calendario FullCalendar (vista mensual) ────────────────────────── -->
    <div class="sb-admin-card">
        <div class="sb-admin-card-header">
            <h2 class="sb-admin-card-title">🗓️ Vista Mensual de Reservas</h2>
        </div>
        <div id="sb-admin-calendar" style="padding: 1rem;"></div>
    </div>

</div><!-- /.wrap -->
