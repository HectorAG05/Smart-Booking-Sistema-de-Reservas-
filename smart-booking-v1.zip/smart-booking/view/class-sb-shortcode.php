<?php
/**
 * Vista – Shortcode del Frontend
 *
 * Registra el shortcode [smart_booking] y encola los assets necesarios
 * para el calendario y el formulario de reservas.
 *
 * Uso: [smart_booking] en cualquier página o entrada de WordPress.
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SB_Shortcode {

    /** Registra el shortcode y los hooks de assets. */
    public static function register(): void {
        add_shortcode( 'smart_booking', [ self::class, 'render' ] );
        add_action( 'wp_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
    }

    /** Encola los assets del frontend. */
    public static function enqueue_assets(): void {
        // Solo cargar si el shortcode está presente en la página actual
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) || ! has_shortcode( $post->post_content, 'smart_booking' ) ) {
            return;
        }

        // FullCalendar
        wp_enqueue_script(
            'fullcalendar',
            'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js',
            [],
            '6.1.11',
            true
        );

        // Tailwind CSS
        wp_enqueue_script(
            'tailwindcss',
            'https://cdn.tailwindcss.com',
            [],
            null,
            false
        );

        // CSS del plugin
        wp_enqueue_style(
            'smart-booking-frontend',
            SB_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            SB_VERSION
        );

        // JS principal del frontend
        wp_enqueue_script(
            'smart-booking-frontend',
            SB_PLUGIN_URL . 'assets/js/frontend.js',
            [ 'fullcalendar' ],
            SB_VERSION,
            true
        );

        // Datos globales para el JS
        wp_localize_script( 'smart-booking-frontend', 'sbConfig', [
            'apiBase'  => rest_url( 'smart-booking/v1' ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'services' => SB_Booking::SERVICES,
            'openHour' => SB_Booking::OPEN_HOUR,
            'closeHour'=> SB_Booking::CLOSE_HOUR,
        ] );
    }

    /**
     * Renderiza el HTML del shortcode.
     *
     * @return string HTML del formulario y calendario.
     */
    public static function render(): string {
        ob_start();
        include SB_PLUGIN_DIR . 'view/booking-form.php';
        return ob_get_clean();
    }
}
