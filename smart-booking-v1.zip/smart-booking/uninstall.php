<?php
/**
 * Desinstalación del Plugin Smart-Booking
 *
 * Este archivo se ejecuta cuando el usuario elimina el plugin desde
 * el panel de WordPress. Limpia todos los datos del plugin:
 *  - Tabla de la base de datos
 *  - Opciones de configuración
 *  - Transients almacenados
 *
 * IMPORTANTE: Solo se ejecuta si el plugin fue desinstalado correctamente
 * desde el panel de WordPress, no al desactivarlo.
 *
 * @package Smart_Booking
 */

// Seguridad: verificar que WordPress está ejecutando esta acción
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// ─── 1. Eliminar la tabla de reservas ─────────────────────────────────────────
$table = $wpdb->prefix . 'booking_system';
$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL

// ─── 2. Eliminar opciones de configuración ────────────────────────────────────
$options = [
    'sb_whatsapp_token',
    'sb_whatsapp_number',
    'sb_business_name',
];

foreach ( $options as $option ) {
    delete_option( $option );
}

// ─── 3. Eliminar transients ───────────────────────────────────────────────────
$wpdb->query(
    "DELETE FROM {$wpdb->options}
     WHERE option_name LIKE '_transient_sb_wa_link_%'
        OR option_name LIKE '_transient_timeout_sb_wa_link_%'"
); // phpcs:ignore WordPress.DB.PreparedSQL
