<?php
/**
 * Controlador – Panel de Administración (wp-admin)
 *
 * Registra las páginas del menú de administración, encola los assets
 * del dashboard y procesa las acciones administrativas (confirmar/cancelar).
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SB_Admin_Controller {

    /** Registra todos los hooks de administración. */
    public static function register(): void {
        add_action( 'admin_menu',            [ self::class, 'add_menu_pages' ] );
        add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
        add_action( 'admin_post_sb_update_status', [ self::class, 'handle_status_update' ] );
    }

    /** Agrega las páginas al menú de WordPress. */
    public static function add_menu_pages(): void {
        add_menu_page(
            'Smart Booking',
            'Smart Booking',
            'manage_options',
            'smart-booking',
            [ self::class, 'render_dashboard' ],
            'dashicons-calendar-alt',
            30
        );

        add_submenu_page(
            'smart-booking',
            'Turnos del Día',
            'Turnos del Día',
            'manage_options',
            'smart-booking',
            [ self::class, 'render_dashboard' ]
        );

        add_submenu_page(
            'smart-booking',
            'Configuración',
            'Configuración',
            'manage_options',
            'smart-booking-settings',
            [ self::class, 'render_settings' ]
        );
    }

    /** Encola CSS y JS solo en las páginas del plugin. */
    public static function enqueue_assets( string $hook ): void {
        if ( ! str_contains( $hook, 'smart-booking' ) ) {
            return;
        }

        // FullCalendar
        wp_enqueue_script(
            'fullcalendar',
            'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js',
            [],
            '6.1.11',
            true
        );

        // Tailwind CSS (CDN para admin)
        wp_enqueue_script(
            'tailwindcss',
            'https://cdn.tailwindcss.com',
            [],
            null,
            false
        );

        // CSS del plugin
        wp_enqueue_style(
            'smart-booking-admin',
            SB_PLUGIN_URL . 'assets/css/admin.css',
            [],
            SB_VERSION
        );

        // JS del dashboard
        wp_enqueue_script(
            'smart-booking-admin',
            SB_PLUGIN_URL . 'assets/js/admin.js',
            [ 'fullcalendar' ],
            SB_VERSION,
            true
        );

        // Pasar datos al JS
        wp_localize_script( 'smart-booking-admin', 'sbAdmin', [
            'apiBase'  => rest_url( 'smart-booking/v1' ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'services' => SB_Booking::SERVICES,
            'ajaxUrl'  => admin_url( 'admin-post.php' ),
        ] );
    }

    /** Renderiza el dashboard principal con la tabla de turnos del día. */
    public static function render_dashboard(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'No tienes permisos para acceder a esta página.', 'smart-booking' ) );
        }

        // Filtro de fecha (por defecto: hoy)
        $filter_date = isset( $_GET['sb_date'] )
            ? sanitize_text_field( $_GET['sb_date'] )
            : current_time( 'Y-m-d' );

        // Validar formato de fecha
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $filter_date ) ) {
            $filter_date = current_time( 'Y-m-d' );
        }

        $bookings = SB_Database::get_bookings_by_date( $filter_date );

        // Estadísticas del día
        $stats = [
            'total'      => count( $bookings ),
            'confirmado' => count( array_filter( $bookings, fn( $b ) => $b['status'] === 'confirmado' ) ),
            'pendiente'  => count( array_filter( $bookings, fn( $b ) => $b['status'] === 'pendiente' ) ),
            'cancelado'  => count( array_filter( $bookings, fn( $b ) => $b['status'] === 'cancelado' ) ),
        ];

        include SB_PLUGIN_DIR . 'view/admin-dashboard.php';
    }

    /** Renderiza la página de configuración del plugin. */
    public static function render_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'No tienes permisos para acceder a esta página.', 'smart-booking' ) );
        }

        // Guardar configuración
        if ( isset( $_POST['sb_save_settings'] ) && check_admin_referer( 'sb_settings_nonce' ) ) {
            $whatsapp_token  = sanitize_text_field( $_POST['sb_whatsapp_token'] ?? '' );
            $whatsapp_number = sanitize_text_field( $_POST['sb_whatsapp_number'] ?? '' );
            $business_name   = sanitize_text_field( $_POST['sb_business_name'] ?? '' );

            update_option( 'sb_whatsapp_token',  $whatsapp_token );
            update_option( 'sb_whatsapp_number', $whatsapp_number );
            update_option( 'sb_business_name',   $business_name );

            echo '<div class="notice notice-success"><p>Configuración guardada correctamente.</p></div>';
        }

        $whatsapp_token  = get_option( 'sb_whatsapp_token',  '' );
        $whatsapp_number = get_option( 'sb_whatsapp_number', '' );
        $business_name   = get_option( 'sb_business_name',   'Mi Negocio' );

        include SB_PLUGIN_DIR . 'view/admin-settings.php';
    }

    /**
     * Maneja la actualización de estado desde el dashboard (acción POST).
     * Redirige de vuelta al dashboard con un mensaje de éxito/error.
     */
    public static function handle_status_update(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'No autorizado.' );
        }

        check_admin_referer( 'sb_status_update' );

        $id     = absint( $_POST['booking_id'] ?? 0 );
        $status = sanitize_text_field( $_POST['new_status'] ?? '' );
        $date   = sanitize_text_field( $_POST['filter_date'] ?? current_time( 'Y-m-d' ) );

        try {
            if ( ! $id || ! in_array( $status, [ 'pendiente', 'confirmado', 'cancelado' ], true ) ) {
                throw new InvalidArgumentException( 'Datos inválidos.' );
            }

            $booking = SB_Database::get_booking_by_id( $id );
            if ( ! $booking ) {
                throw new RuntimeException( 'Turno no encontrado.' );
            }

            SB_Database::update_status( $id, $status );

            // Enviar notificación si se confirma
            if ( 'confirmado' === $status ) {
                SB_WhatsApp::send_confirmation( $id, $booking );
            }

            $redirect = add_query_arg(
                [ 'page' => 'smart-booking', 'sb_date' => $date, 'sb_msg' => 'updated' ],
                admin_url( 'admin.php' )
            );

        } catch ( Throwable $e ) {
            error_log( '[Smart-Booking] Error en handle_status_update: ' . $e->getMessage() );
            $redirect = add_query_arg(
                [ 'page' => 'smart-booking', 'sb_date' => $date, 'sb_msg' => 'error' ],
                admin_url( 'admin.php' )
            );
        }

        wp_safe_redirect( $redirect );
        exit;
    }
}
