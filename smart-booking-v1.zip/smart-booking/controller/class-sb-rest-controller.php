<?php
/**
 * Controlador – REST API
 *
 * Registra los endpoints de la WordPress REST API bajo el namespace
 * "smart-booking/v1". Gestiona la lógica de validación, anti-overbooking
 * e integración con WhatsApp antes de persistir en la BD.
 *
 * Endpoints:
 *   POST   /wp-json/smart-booking/v1/bookings          → Crear turno
 *   GET    /wp-json/smart-booking/v1/bookings           → Listar eventos (calendario)
 *   GET    /wp-json/smart-booking/v1/slots              → Slots disponibles
 *   PATCH  /wp-json/smart-booking/v1/bookings/{id}     → Actualizar estado
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SB_Rest_Controller {

    private const NAMESPACE = 'smart-booking/v1';

    /** Registra los hooks de WordPress REST API. */
    public static function register(): void {
        add_action( 'rest_api_init', [ self::class, 'register_routes' ] );
    }

    /** Define todas las rutas REST. */
    public static function register_routes(): void {

        // ── Crear turno ────────────────────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/bookings', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ self::class, 'create_booking' ],
            'permission_callback' => '__return_true',
            'args'                => self::booking_args(),
        ] );

        // ── Listar eventos para FullCalendar ───────────────────────────────────
        register_rest_route( self::NAMESPACE, '/bookings', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ self::class, 'get_events' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'start' => [
                    'required'          => true,
                    'validate_callback' => fn( $v ) => (bool) preg_match( '/^\d{4}-\d{2}-\d{2}/', $v ),
                ],
                'end'   => [
                    'required'          => true,
                    'validate_callback' => fn( $v ) => (bool) preg_match( '/^\d{4}-\d{2}-\d{2}/', $v ),
                ],
            ],
        ] );

        // ── Slots disponibles ──────────────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/slots', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ self::class, 'get_slots' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'date'         => [
                    'required'          => true,
                    'validate_callback' => fn( $v ) => (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ),
                ],
                'service_type' => [
                    'required'          => true,
                    'validate_callback' => fn( $v ) => array_key_exists( $v, SB_Booking::SERVICES ),
                ],
            ],
        ] );

        // ── Actualizar estado (solo admins) ────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/bookings/(?P<id>\d+)', [
            'methods'             => 'PATCH',
            'callback'            => [ self::class, 'update_booking_status' ],
            'permission_callback' => fn() => current_user_can( 'manage_options' ),
            'args'                => [
                'id'     => [
                    'required'          => true,
                    'validate_callback' => fn( $v ) => is_numeric( $v ) && $v > 0,
                    'sanitize_callback' => 'absint',
                ],
                'status' => [
                    'required'          => true,
                    'validate_callback' => fn( $v ) => in_array( $v, [ 'pendiente', 'confirmado', 'cancelado' ], true ),
                ],
            ],
        ] );
    }

    // ─── Handlers ─────────────────────────────────────────────────────────────

    /**
     * POST /bookings – Crea un nuevo turno con validación anti-overbooking.
     */
    public static function create_booking( WP_REST_Request $request ): WP_REST_Response {
        try {
            $data = $request->get_json_params() ?: $request->get_body_params();

            // 1. Validación de negocio
            $validation = SB_Booking::validate( $data );
            if ( ! $validation['valid'] ) {
                return new WP_REST_Response(
                    [ 'success' => false, 'errors' => $validation['errors'] ],
                    422
                );
            }

            $date    = sanitize_text_field( $data['booking_date'] );
            $service = sanitize_text_field( $data['service_type'] );
            $start   = sanitize_text_field( $data['start_time'] );
            $end     = SB_Booking::calculate_end_time( $service, $start );

            // 2. Verificación de colisión (anti-overbooking)
            if ( SB_Database::has_overlap( $date, $start, $end, $service ) ) {
                return new WP_REST_Response(
                    [
                        'success' => false,
                        'errors'  => [ 'El horario seleccionado ya está ocupado. Por favor elige otro slot.' ],
                    ],
                    409
                );
            }

            // 3. Persistencia
            $insert_data              = $data;
            $insert_data['end_time']  = $end;
            $insert_data['start_time'] = $start;

            $booking_id = SB_Database::insert_booking( $insert_data );

            if ( ! $booking_id ) {
                throw new RuntimeException( 'No se pudo insertar el turno en la base de datos.' );
            }

            // 4. Notificación WhatsApp (asíncrona, no bloquea la respuesta)
            SB_WhatsApp::send_confirmation( $booking_id, $data );

            return new WP_REST_Response(
                [
                    'success'    => true,
                    'booking_id' => $booking_id,
                    'message'    => '¡Turno reservado con éxito! Recibirás una confirmación por WhatsApp.',
                    'end_time'   => $end,
                ],
                201
            );

        } catch ( Throwable $e ) {
            error_log( '[Smart-Booking] Error en create_booking: ' . $e->getMessage() );
            return new WP_REST_Response(
                [ 'success' => false, 'errors' => [ 'Error interno del servidor. Intenta nuevamente.' ] ],
                500
            );
        }
    }

    /**
     * GET /bookings – Devuelve eventos para FullCalendar.
     */
    public static function get_events( WP_REST_Request $request ): WP_REST_Response {
        try {
            $start = sanitize_text_field( substr( $request->get_param( 'start' ), 0, 10 ) );
            $end   = sanitize_text_field( substr( $request->get_param( 'end' ),   0, 10 ) );

            $rows   = SB_Database::get_events_for_calendar( $start, $end );
            $events = SB_Booking::format_for_calendar( $rows );

            return new WP_REST_Response( $events, 200 );

        } catch ( Throwable $e ) {
            error_log( '[Smart-Booking] Error en get_events: ' . $e->getMessage() );
            return new WP_REST_Response( [], 500 );
        }
    }

    /**
     * GET /slots – Devuelve los slots disponibles para una fecha y servicio.
     */
    public static function get_slots( WP_REST_Request $request ): WP_REST_Response {
        try {
            $date    = sanitize_text_field( $request->get_param( 'date' ) );
            $service = sanitize_text_field( $request->get_param( 'service_type' ) );

            $slots = SB_Booking::generate_slots( $date, $service );

            return new WP_REST_Response( [ 'success' => true, 'slots' => $slots ], 200 );

        } catch ( Throwable $e ) {
            error_log( '[Smart-Booking] Error en get_slots: ' . $e->getMessage() );
            return new WP_REST_Response( [ 'success' => false, 'slots' => [] ], 500 );
        }
    }

    /**
     * PATCH /bookings/{id} – Actualiza el estado de un turno (solo admins).
     */
    public static function update_booking_status( WP_REST_Request $request ): WP_REST_Response {
        try {
            $id     = (int) $request->get_param( 'id' );
            $status = sanitize_text_field( $request->get_param( 'status' ) );

            $booking = SB_Database::get_booking_by_id( $id );
            if ( ! $booking ) {
                return new WP_REST_Response(
                    [ 'success' => false, 'errors' => [ 'Turno no encontrado.' ] ],
                    404
                );
            }

            $updated = SB_Database::update_status( $id, $status );

            if ( ! $updated ) {
                throw new RuntimeException( 'No se pudo actualizar el estado.' );
            }

            // Notificar al usuario si el turno fue confirmado
            if ( 'confirmado' === $status ) {
                SB_WhatsApp::send_confirmation( $id, $booking );
            }

            return new WP_REST_Response(
                [ 'success' => true, 'message' => 'Estado actualizado correctamente.' ],
                200
            );

        } catch ( Throwable $e ) {
            error_log( '[Smart-Booking] Error en update_booking_status: ' . $e->getMessage() );
            return new WP_REST_Response(
                [ 'success' => false, 'errors' => [ 'Error interno del servidor.' ] ],
                500
            );
        }
    }

    // ─── Definición de argumentos REST ────────────────────────────────────────

    private static function booking_args(): array {
        return [
            'user_name'      => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'validate_callback' => fn( $v ) => strlen( trim( $v ) ) >= 2,
            ],
            'service_type'   => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => fn( $v ) => array_key_exists( $v, SB_Booking::SERVICES ),
            ],
            'booking_date'   => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => fn( $v ) => (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ),
            ],
            'start_time'     => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => fn( $v ) => (bool) preg_match( '/^\d{2}:\d{2}(:\d{2})?$/', $v ),
            ],
            'whatsapp_phone' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => fn( $v ) => preg_replace( '/\D/', '', $v ),
                'validate_callback' => fn( $v ) => strlen( preg_replace( '/\D/', '', $v ) ) >= 7,
            ],
        ];
    }
}
