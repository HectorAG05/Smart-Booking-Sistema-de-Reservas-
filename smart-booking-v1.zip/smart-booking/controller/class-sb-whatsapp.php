<?php
/**
 * Integración WhatsApp
 *
 * Gestiona el envío de mensajes de confirmación mediante dos estrategias:
 *
 *  1. URL Masking (wa.me): No requiere token. Genera un enlace clickeable
 *     que el administrador puede usar para contactar al cliente. Ideal para
 *     pequeños negocios sin acceso a la API oficial.
 *
 *  2. WhatsApp Business API (Meta): Envía mensajes automáticos mediante
 *     la API oficial de Meta para Developers. Requiere un token de acceso
 *     y un número de teléfono registrado en Meta Business.
 *
 * La estrategia se selecciona automáticamente según la configuración:
 *  - Si existe un token configurado → API oficial.
 *  - Si no hay token → URL masking (enlace en el dashboard).
 *
 * @package Smart_Booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SB_WhatsApp {

    // ─── Constantes ───────────────────────────────────────────────────────────
    private const API_URL = 'https://graph.facebook.com/v18.0/%s/messages';
    private const TIMEOUT = 10; // segundos

    /**
     * Punto de entrada principal: envía la confirmación al cliente.
     *
     * @param int   $booking_id ID del turno recién creado.
     * @param array $data       Datos del turno.
     * @return bool TRUE si el mensaje fue enviado (o encolado) correctamente.
     */
    public static function send_confirmation( int $booking_id, array $data ): bool {
        try {
            $token  = get_option( 'sb_whatsapp_token',  '' );
            $number = get_option( 'sb_whatsapp_number', '' );

            if ( ! empty( $token ) && ! empty( $number ) ) {
                return self::send_via_api( $booking_id, $data, $token, $number );
            }

            // Fallback: registrar el enlace de wa.me en el log del plugin
            return self::log_url_masking( $booking_id, $data );

        } catch ( Throwable $e ) {
            error_log( '[Smart-Booking] WhatsApp error: ' . $e->getMessage() );
            return false;
        }
    }

    // ─── Estrategia 1: API oficial de WhatsApp Business ───────────────────────

    /**
     * Envía un mensaje de texto mediante la API de WhatsApp Business (Meta).
     *
     * @param int    $booking_id  ID del turno.
     * @param array  $data        Datos del turno.
     * @param string $token       Token de acceso de la API.
     * @param string $from_number Número de teléfono del negocio (ID de Meta).
     * @return bool
     */
    private static function send_via_api(
        int    $booking_id,
        array  $data,
        string $token,
        string $from_number
    ): bool {
        $message = self::build_message( $booking_id, $data );
        $to      = preg_replace( '/\D/', '', $data['whatsapp_phone'] ?? '' );

        if ( empty( $to ) ) {
            return false;
        }

        $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'text',
            'text'              => [ 'body' => $message ],
        ];

        $url = sprintf( self::API_URL, $from_number );

        $response = wp_remote_post( $url, [
            'timeout' => self::TIMEOUT,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( $payload ),
        ] );

        if ( is_wp_error( $response ) ) {
            error_log( '[Smart-Booking] WhatsApp API WP_Error: ' . $response->get_error_message() );
            return false;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body        = wp_remote_retrieve_body( $response );

        if ( $status_code < 200 || $status_code >= 300 ) {
            error_log( "[Smart-Booking] WhatsApp API HTTP {$status_code}: {$body}" );
            return false;
        }

        error_log( "[Smart-Booking] WhatsApp API OK – Booking #{$booking_id} → +{$to}" );
        return true;
    }

    // ─── Estrategia 2: URL Masking (wa.me) ────────────────────────────────────

    /**
     * Genera y registra el enlace de wa.me para que el administrador
     * lo use desde el dashboard sin necesidad de token.
     *
     * @param int   $booking_id  ID del turno.
     * @param array $data        Datos del turno.
     * @return bool
     */
    private static function log_url_masking( int $booking_id, array $data ): bool {
        $message = self::build_message( $booking_id, $data );
        $phone   = preg_replace( '/\D/', '', $data['whatsapp_phone'] ?? '' );

        if ( empty( $phone ) ) {
            return false;
        }

        $url = 'https://wa.me/' . $phone . '?text=' . rawurlencode( $message );

        // Guardar el enlace en la meta del turno (tabla de opciones transitoria)
        set_transient( "sb_wa_link_{$booking_id}", $url, DAY_IN_SECONDS );

        error_log( "[Smart-Booking] WhatsApp URL Masking – Booking #{$booking_id}: {$url}" );
        return true;
    }

    /**
     * Obtiene el enlace de wa.me para un turno específico.
     * Útil para mostrarlo en el dashboard.
     *
     * @param int $booking_id ID del turno.
     * @return string|null URL de wa.me o null si no existe.
     */
    public static function get_wa_link( int $booking_id ): ?string {
        $link = get_transient( "sb_wa_link_{$booking_id}" );
        return $link ?: null;
    }

    // ─── Construcción del mensaje ──────────────────────────────────────────────

    /**
     * Construye el texto del mensaje de confirmación.
     *
     * @param int   $booking_id ID del turno.
     * @param array $data       Datos del turno.
     * @return string Mensaje formateado.
     */
    private static function build_message( int $booking_id, array $data ): string {
        $business_name = get_option( 'sb_business_name', 'Nuestro Centro' );
        $service_key   = $data['service_type'] ?? '';
        $service_label = SB_Booking::SERVICES[ $service_key ]['label'] ?? $service_key;

        $date_obj = date_create( $data['booking_date'] ?? '' );
        $date_str = $date_obj
            ? $date_obj->format( 'd/m/Y' )
            : ( $data['booking_date'] ?? '—' );

        $start = substr( $data['start_time'] ?? '—', 0, 5 );
        $end   = substr( $data['end_time']   ?? '—', 0, 5 );

        $name  = $data['user_name'] ?? 'Cliente';

        return <<<MSG
        ✅ *Confirmación de Turno – {$business_name}*

        Hola {$name}, tu reserva fue registrada exitosamente.

        📋 *Detalles:*
        • N° de Turno: #{$booking_id}
        • Servicio: {$service_label}
        • Fecha: {$date_str}
        • Horario: {$start} – {$end}

        ⚠️ Si necesitas cancelar o reprogramar, contáctanos con anticipación.

        ¡Gracias por elegirnos! 🙏
        MSG;
    }

    // ─── Generador de enlace wa.me directo ────────────────────────────────────

    /**
     * Genera un enlace wa.me con el mensaje de confirmación pre-cargado.
     * Útil para botones en el dashboard administrativo.
     *
     * @param int   $booking_id ID del turno.
     * @param array $data       Datos del turno.
     * @return string URL completa de wa.me.
     */
    public static function generate_wa_url( int $booking_id, array $data ): string {
        $message = self::build_message( $booking_id, $data );
        $phone   = preg_replace( '/\D/', '', $data['whatsapp_phone'] ?? '' );
        return 'https://wa.me/' . $phone . '?text=' . rawurlencode( $message );
    }
}
