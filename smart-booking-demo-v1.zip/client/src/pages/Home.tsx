import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Check, Clock, Shield, Zap, Users, BarChart3, Download, Github, ExternalLink } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold">
              📅
            </div>
            <span className="text-lg font-bold">Smart-Booking</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition">
              Características
            </a>
            <a href="#demo" className="text-sm text-muted-foreground hover:text-foreground transition">
              Demo
            </a>
            <a href="#faq" className="text-sm text-muted-foreground hover:text-foreground transition">
              Preguntas
            </a>
            <Button variant="outline" size="sm">
              Descargar
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none" />
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-6">
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium">Sistema de Reservas Inteligente</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Reservas sin <span className="text-primary">Overbooking</span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Smart-Booking es un plugin de WordPress que revoluciona la gestión de turnos para clínicas, gimnasios y servicios profesionales. Elimina conflictos de horario con validación en tiempo real y notificaciones automáticas por WhatsApp.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="gap-2">
                <Download className="w-4 h-4" />
                Descargar Plugin
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Github className="w-4 h-4" />
                Ver en GitHub
              </Button>
            </div>

            <div className="mt-12 grid grid-cols-3 gap-4 text-sm">
              <div className="flex flex-col items-center">
                <div className="text-2xl font-bold text-primary">100%</div>
                <div className="text-muted-foreground">Anti-Overbooking</div>
              </div>
              <div className="flex flex-col items-center">
                <div className="text-2xl font-bold text-primary">⚡</div>
                <div className="text-muted-foreground">Tiempo Real</div>
              </div>
              <div className="flex flex-col items-center">
                <div className="text-2xl font-bold text-primary">📱</div>
                <div className="text-muted-foreground">WhatsApp</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 md:py-32 bg-card/50">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Características Principales</h2>
            <p className="text-lg text-muted-foreground">
              Todo lo que necesitas para gestionar reservas de forma profesional
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Feature 1 */}
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                    <Shield className="w-6 h-6" />
                  </div>
                  <div>
                    <CardTitle>Validación Anti-Overbooking</CardTitle>
                    <CardDescription>Previene conflictos de horario</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Algoritmo de servidor que verifica disponibilidad en tiempo real antes de confirmar cada reserva. Imposible sobrevender turnos.
                </p>
              </CardContent>
            </Card>

            {/* Feature 2 */}
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <CardTitle>Calendario Interactivo</CardTitle>
                    <CardDescription>FullCalendar.js integrado</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Vista mensual y diaria de turnos. Slots dinámicos según duración del servicio. Interfaz intuitiva y responsive.
                </p>
              </CardContent>
            </Card>

            {/* Feature 3 */}
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <CardTitle>Notificaciones WhatsApp</CardTitle>
                    <CardDescription>Confirmaciones automáticas</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Envía confirmaciones de reserva vía WhatsApp Business API o URL masking. Soporte para múltiples idiomas.
                </p>
              </CardContent>
            </Card>

            {/* Feature 4 */}
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                    <BarChart3 className="w-6 h-6" />
                  </div>
                  <div>
                    <CardTitle>Dashboard Administrativo</CardTitle>
                    <CardDescription>Gestión completa en wp-admin</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Tabla de turnos del día con filtros, estadísticas en tiempo real y acciones rápidas (confirmar/cancelar).
                </p>
              </CardContent>
            </Card>

            {/* Feature 5 */}
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <CardTitle>REST API Completa</CardTitle>
                    <CardDescription>WordPress REST API</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Endpoints para crear reservas, obtener slots y gestionar eventos. Validación de datos en servidor.
                </p>
              </CardContent>
            </Card>

            {/* Feature 6 */}
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                    <Check className="w-6 h-6" />
                  </div>
                  <div>
                    <CardTitle>Seguridad Robusta</CardTitle>
                    <CardDescription>Prevención de inyecciones SQL</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Consultas preparadas, sanitización de datos, nonces de WordPress y manejo de errores con try-catch.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section id="demo" className="py-20 md:py-32">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Cómo Funciona</h2>
            <p className="text-lg text-muted-foreground">
              Un flujo de reservas en 3 pasos, diseñado para ser intuitivo y rápido
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Tabs defaultValue="step1" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-8">
                <TabsTrigger value="step1" className="gap-2">
                  <span className="hidden sm:inline">Paso 1:</span> Servicio
                </TabsTrigger>
                <TabsTrigger value="step2" className="gap-2">
                  <span className="hidden sm:inline">Paso 2:</span> Horario
                </TabsTrigger>
                <TabsTrigger value="step3" className="gap-2">
                  <span className="hidden sm:inline">Paso 3:</span> Confirmación
                </TabsTrigger>
              </TabsList>

              <TabsContent value="step1">
                <Card>
                  <CardHeader>
                    <CardTitle>Selecciona el Servicio</CardTitle>
                    <CardDescription>
                      El usuario elige entre consulta médica, fisioterapia, entrenamiento, etc.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-muted/50 rounded-lg p-8 text-center">
                      <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
                        {["🩺 Consulta", "🦴 Fisio", "🏋️ Entreno", "🥗 Nutrición"].map((service) => (
                          <div key={service} className="bg-background border border-border rounded-lg p-4 text-sm font-medium">
                            {service}
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="step2">
                <Card>
                  <CardHeader>
                    <CardTitle>Elige Fecha y Horario</CardTitle>
                    <CardDescription>
                      Calendario interactivo muestra solo slots disponibles
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-muted/50 rounded-lg p-8">
                      <div className="grid grid-cols-3 gap-2 mb-6">
                        {["09:00", "10:00", "11:00", "14:00", "15:00"].map((time) => (
                          <button
                            key={time}
                            className="bg-primary text-primary-foreground rounded-lg py-2 text-sm font-medium hover:bg-primary/90 transition"
                          >
                            {time}
                          </button>
                        ))}
                        {["12:00", "13:00", "16:00"].map((time) => (
                          <button
                            key={time}
                            className="bg-muted text-muted-foreground rounded-lg py-2 text-sm font-medium cursor-not-allowed opacity-50"
                            disabled
                          >
                            {time}
                          </button>
                        ))}
                      </div>
                      <p className="text-sm text-muted-foreground text-center">
                        Los horarios grises están ocupados
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="step3">
                <Card>
                  <CardHeader>
                    <CardTitle>Completa tus Datos</CardTitle>
                    <CardDescription>
                      Nombre y WhatsApp para la confirmación
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium">Nombre Completo</label>
                        <input
                          type="text"
                          placeholder="María García"
                          className="w-full mt-2 px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">WhatsApp</label>
                        <input
                          type="tel"
                          placeholder="+5491112345678"
                          className="w-full mt-2 px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <Button className="w-full">Confirmar Reserva</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 md:py-32 bg-card/50">
        <div className="container">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Preguntas Frecuentes</h2>
              <p className="text-lg text-muted-foreground">
                Resuelve tus dudas sobre Smart-Booking
              </p>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>¿Cómo se instala el plugin?</AccordionTrigger>
                <AccordionContent>
                  Descarga el archivo ZIP, ve a tu WordPress en Plugins → Añadir nuevo, sube el archivo y actívalo. Luego, usa el shortcode [smart_booking] en cualquier página.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger>¿Necesito la API de WhatsApp?</AccordionTrigger>
                <AccordionContent>
                  No es obligatorio. Si no tienes token, el sistema genera enlaces wa.me que puedes usar para enviar mensajes manualmente desde el dashboard.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger>¿Cómo funciona la validación anti-overbooking?</AccordionTrigger>
                <AccordionContent>
                  Antes de confirmar cada reserva, el servidor ejecuta una consulta SQL que verifica si hay conflictos de horario. Si hay solapamiento, rechaza la reserva automáticamente.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger>¿Puedo personalizar los servicios?</AccordionTrigger>
                <AccordionContent>
                  Sí. En el código puedes editar el array SERVICES en class-sb-booking.php para añadir tus propios servicios con sus duraciones.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5">
                <AccordionTrigger>¿Es seguro el plugin?</AccordionTrigger>
                <AccordionContent>
                  Sí. Implementa consultas preparadas, sanitización de datos, nonces de WordPress y validación en servidor para prevenir inyecciones SQL y ataques CSRF.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6">
                <AccordionTrigger>¿Puedo ver el código?</AccordionTrigger>
                <AccordionContent>
                  Claro. El plugin está disponible en GitHub con documentación técnica completa. Puedes revisar, modificar y contribuir al proyecto.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-gradient-to-br from-primary/10 via-transparent to-accent/10">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-4xl font-bold mb-6">¿Listo para mejorar tus reservas?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Smart-Booking es la solución que tu negocio necesita para eliminar conflictos de horario y mejorar la experiencia del cliente.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="gap-2">
                <Download className="w-4 h-4" />
                Descargar Ahora
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <ExternalLink className="w-4 h-4" />
                Documentación
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 bg-card/50">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold">
                  📅
                </div>
                <span className="font-bold">Smart-Booking</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Sistema de reservas inteligente para WordPress
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Producto</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#features" className="hover:text-foreground transition">Características</a></li>
                <li><a href="#demo" className="hover:text-foreground transition">Demo</a></li>
                <li><a href="#faq" className="hover:text-foreground transition">Preguntas</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Recursos</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition">Documentación</a></li>
                <li><a href="#" className="hover:text-foreground transition">GitHub</a></li>
                <li><a href="#" className="hover:text-foreground transition">Soporte</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition">Licencia</a></li>
                <li><a href="#" className="hover:text-foreground transition">Privacidad</a></li>
                <li><a href="#" className="hover:text-foreground transition">Términos</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>© 2026 Smart-Booking. Desarrollado con ❤️ por Hector George.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
